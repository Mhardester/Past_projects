
    ###########################################################
    #  Cse 231 Project #4
    #  Define a factorial function
    #  Define several mathmatical functions to approximate irrational numbers
    #  Ask user to select from a menu of options
    #  User can keep playing until they select "x"
    #  Print approximated and calculated results of selected options
    ###########################################################  
import math
EPSILON = 0.0000001
menu_options="fepsmx"
MENU = '''\nOptions below:
    ‘F’: Factorial of N.
    ‘E’: Approximate value of e.
    ‘P’: Approximate value of Pi.
    ‘S’: Approximate value of the sinh of X.
    ‘M’: Display the menu of options.
    ‘X’: Exit.
'''

def factorial(N):
    """
    Factorial can only be used for non-negative integers 
    N is multiplied by every number that comes before it
    Return value of N
    """
    N=int(N)
    if N < 0:
        return None 
    if N == 0 or N == 1:
        return 1
    else:
        fact = 1
        while(N > 1):
            fact *= N
            N -= 1
        return fact
 
def e(): 
    """
    Using 1/factorial of numbers 1-10 gives a solid estimate of e
    """
    e=0
    for i in range(0,11):
        e+=(1/math.factorial(i))
    e=round(e,10)
    return e

def pi():
    """
    create a counter/denominator
    Initialize sum of pi
    even indices are positive
    odd indices are negative
    """
    c = 1  
    pie= 0
    for i in range(5000000):
        if i % 2 == 0:
            pie += 4/c
        else:
            pie -= 4/c
 
        # when denominator is odd
        c += 2
    pie=round(pie,10)
    return pie

def sinh(s):
    """
    starting at 1, count by every other number, and use each number 
    in the hyperbolic sine equation
    number must be converted to a float
    """
    try:
         s=float(s)
    except ValueError:
        return None  
    sin=0
    i=1
    while math.fabs((s**i)/(math.factorial(i)))>EPSILON:
        sin+=(s**i)/(math.factorial(i))
        i+=2
    sin=round(sin,10)
    return sin 
    

def main():
    """
    majority of program goes here
    create control statements based on each possible input
    print required outputs based input
    call functions when necessary
    program ends when 'x' is input
    """ 
    print(MENU) 
    prompt=input("\nChoose an option: ")
    prompt=prompt.lower()
    while prompt !="x":
        while prompt=="f":
            print ("\nFactorial")
            n=(input("Input non-negative integer N: "))
            #code below will allow a bypass of Value Errors
            try:
                n=int(n)
            except ValueError:
                print("\nInvalid N.")
                prompt=input("\nChoose an option: ")
                prompt=prompt.lower()
                break

            if int(n)<0:
                print("\nInvalid N.")
                prompt=input("\nChoose an option: ")
                prompt=prompt.lower()
            if int(n)>=0:
                math_f=math.factorial(n)
                n=factorial(n)
                diff=int(math.fabs(n-math_f))
                print("\nCalculated:",n)
                print("Math:",math_f)
                print("Diff:",diff)
                prompt=input("\nChoose an option: ")
                prompt=prompt.lower()

        while prompt=="e":
            e_funct=e()
            calc_e = math.e
            calc_e=round(calc_e,10)
            diff_e = calc_e - e_funct
            print("\ne")
            print("Calculated:",e_funct)
            print("Math:",round(calc_e,10))
            print("Diff: {:.10f}".format(diff_e))
            prompt=input("\nChoose an option: ")
            prompt=prompt.lower()

        while prompt=="p":
            pi_funct=pi()
            calc_pi=math.pi
            diff_p = math.pi - pi_funct
            print("\npi")
            print("Calculated:",pi_funct)
            print("Math:",round(calc_pi,10))
            print("Diff: {:.10f}".format(diff_p))
            prompt=input("\nChoose an option: ")
            prompt=prompt.lower()

        while prompt=="s":
            print("\nsinh")
            x_radians=((input("X in radians: ")))
            try:
                x_radians=float(x_radians)
            except ValueError:
                    print("\nInvalid X.")
                    prompt=input("\nChoose an option: ")
                    break         
            x_radians=float(x_radians)
            sin_funct=sinh(x_radians)
            calc_sin=math.sinh(x_radians)
            diff_sin= calc_sin - sin_funct
            print("\nCalculated:",round(sin_funct,10))
            print("Math:",round(calc_sin,10))
            print("Diff: {:.10f}".format(diff_sin))
            prompt=input("\nChoose an option: ")
            prompt=prompt.lower()

        while prompt=="m":
            print(MENU)
            prompt=input("\nChoose an option: ")
            prompt=prompt.lower()
            
        while prompt not in menu_options:
            print ("\nInvalid option:",prompt.upper())
            print (MENU)
            prompt=input("\nChoose an option: ")
            prompt=prompt.lower()

    if prompt=="x":
        print("\nThank you for playing.")
            
  
if __name__ == '__main__': 
    main()