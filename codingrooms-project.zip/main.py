
    ###########################################################
    #  Cse 231 Project #1
    #  Ask user for an amount of rods
    #  Convert rods to assignmed measurements
    #  Calculate how many minutes it takes to walk the amount of rods
    #  Create print statements showing all of the calculations
    ###########################################################


#prompt for number of rods, and convert to a floating point

rods=input("Input rods: \n")
r_float=float(rods)

#convert rods to assigned measurements

meters=r_float * 5.0292
furlong=r_float / 40
mile= meters / 1609.34
feet= meters / 0.3048
#calculate walking duration in minutes

minutes= mile / 3.1 * 60    #3.1 is MPH, multiply by 60 to convert to minutes

#make print statements

print("You input",r_float,"rods.\n")
print("Conversions")
print("Meters:",round(meters,3))
print("Feet:",round(feet,3))
print("Miles:",round(mile,3))
print("Furlongs:",round(furlong,3))
print("Minutes to walk",r_float,"rods:",round(minutes,3))