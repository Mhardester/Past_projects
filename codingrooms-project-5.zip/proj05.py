
    ###########################################################
    #  Cse 231 Project #5
    #  Define a function that will read an inputted file
    #  Define a function to turn a valid string into a float
    #  Define a function to get the density of a planet
    #  Define a function that checks for a temperature in range
    #  Define a function to check if the distance is in range
    #  Print all required information in the main function
    ###########################################################
import math

#Constants
PI = math.pi   
EARTH_MASS =  5.972E+24    # kg
EARTH_RADIUS = 6.371E+6    # meters
SOLAR_RADIUS = 6.975E+8    # radius of star in meters
AU = 1.496E+11             # distance earth to sun in meters
PARSEC_LY = 3.262

def open_file():
    ''' 
    This function will reapeatedly prompt for a file name until it is valid
    Try-except is used to bypass FileNotFound errors
    '''
    prompt=input("Input data to open: \n")
    prompt=prompt+'.csv'
    while True:
        try:
            file_pointer=open(prompt,'r')
            break
        except FileNotFoundError:
            print('Error: file not found.  Please try again.')
            prompt=input(('Enter a file name: \n'))
            prompt=prompt+'.csv'
    return file_pointer


def make_float(s):
    ''' 
    Function takes a string and converts it to a float if possible
    If it cannot be converted, -1 is returned
    '''
    try:
        s=float(s)
    except ValueError:
        return -1
    else:
        return s
  
def get_density(mass, radius):
    '''
    Function takes mass and radius as parameters
    paramters need to be converted by using provided constants
    Density is mass/volume 
    '''
    if mass<=0 or radius<=0:
        return -1
    else:
        mass*= EARTH_MASS
        radius*= EARTH_RADIUS
        volume= (4/3)*(PI*radius**3)
        density=mass/volume
    return density

def temp_in_range(axis, star_temp, star_radius, albedo, low_bound, upp_bound):
    '''
    Function takes multiple parameters from file data
    If any value is negative, return False
    Use provided equation to determine planet temperature
    Return True if temperature is in between the bounds
    '''
    if axis<0 or star_temp<0 or star_radius<0 or albedo<0 or low_bound<0 or upp_bound<0:
        return False
    star_radius*=SOLAR_RADIUS
    axis*=AU
    planet_temp=star_temp*(star_radius/(axis*2))**0.5*(1-albedo)**0.25
    if planet_temp>=low_bound and planet_temp<= upp_bound:
        return True
    else:
        return False

def get_dist_range():
    '''
    Prompt for a distance, and convert it to a float
    Use try-except until distance is valid
    Once distance is a float that is greater than zero, return distance 
    '''
    dist=input("Enter maximum distance from Earth (light years): \n")
    while True:
        try:
            dist=float(dist)
            break
        except ValueError:
            print("Error: Distance needs to be a float.\n")
            dist=input("Enter maximum distance from Earth (light years): \n")
    while float(dist) <=0:
        print ("Error: Distance needs to be greater than 0.\n")
        dist=input("Enter maximum distance from Earth (light years): \n")
        
    if float(dist)>0:
        return float(dist)

def main():
    '''
    Call file and distance functions, then establish variables
    Use a for loop to read the file
    Preform calculations to get the max planets and stars, total mass, and minimum distance
    Print out required strings and calculations
    '''
         
    print('''Welcome to program that finds nearby exoplanets '''\
          '''in circumstellar habitable zone.''')
    data_file=open_file()
    dist_funct=get_dist_range()
    dist_funct/=PARSEC_LY # Must divide in order to get accurate data
    low_bound=float(200)
    upp_bound=float(350)
    albedo=float(0.5)

    # Set max values to a very low number
    max_value_s=-1
    max_value_p=-1
    
    #These variables will help find average mass, and if planet supports life
    sums=0
    count=0
    habitable=0

    # Set min values to a very high number
    min_rock_dist=1000000
    min_gas_dist=1000000
    
    rocky=0
    gaseous=0
    for line in data_file:
        # Use string slicing to create variables
        distance=make_float(line[114:])
        if distance<=0:
            continue
        if distance>=dist_funct:
            continue
        planet_name= line[:25]
        try:
            num_stars=int(line[50:57])
            num_planets=int(line[58:65])
        except ValueError:
            continue
        axis_distance=make_float(line[66:77])
        radius_planet=make_float(line[78:85])
        mass_planet=make_float(line[86:96])
        star_temp=make_float(line[97:105])
        star_radius=make_float(line[106:113])

        # Find max stars and planets
        if num_stars>max_value_s:
            max_value_s=num_stars
        if num_planets>max_value_p:
            max_value_p=num_planets

        # Only count for masses that are valid, i.e not -1
        if mass_planet>0:
            sums+=mass_planet
            count+=1
        density=get_density(mass_planet,radius_planet)
        y=temp_in_range(axis_distance,star_temp,star_radius,albedo,low_bound,upp_bound)
        if y== True:
            habitable+=1
            if 0<mass_planet<10 or 0<radius_planet<1.5 or density>200:
                rocky+=1

                # Once minimum distance is found, you have the closest planet
                if distance<min_rock_dist:
                    closest_rock_planet=planet_name.strip()
                    min_rock_dist=distance
            else:
                gaseous +=1
                if distance<min_gas_dist:
                    closest_gas_planet=planet_name.strip()
                    min_gas_dist=distance
            
    # Find average mass
    average=sums/count

    # Convert distances to light years, and close the file
    min_rock_dist*=PARSEC_LY
    min_gas_dist*=PARSEC_LY
    data_file.close()

    #Print out data      
    print ("Number of stars in systems with the most stars: {}.".format(max_value_s))
    print ("Number of planets in systems with the most planets: {}.".format(max_value_p))  
    print("Average mass of the planets: {:.2f} Earth masses.".format(average))
    print("Number of planets in circumstellar habitable zone: {}.".format(habitable))
    if rocky ==0:
        print("No rocky planet in circumstellar habitable zone.") 
    if rocky>0:
        print ("Closest rocky planet in the circumstellar habitable zone {} is {:.2f} light years away.".format(closest_rock_planet,min_rock_dist))
    if gaseous>0:
        print("Closest gaseous planet in the circumstellar habitable zone {} is {:.2f} light years away.".format(closest_gas_planet,min_gas_dist))
if __name__ == "__main__":
    main()