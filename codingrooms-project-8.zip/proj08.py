    ###########################################################
    #  Cse 231 Project #8
    #  Define a function to read a file a return a list
    #  Define a function that returns a list of lists of names
    #  Define a function to create a dictionary based on the 2 lists
    #  Define functions to find maximum common friends from the dictionary
    #  Define a function to create secondary friends
    #  Define a function to find max secondary friends
    #  Bases on user input, call functions as necessary
    ###########################################################

MENU = '''
 Menu : 
    1: Popular people (with the most friends). 
    2: Non-friends with the most friends in common.
    3: People with the most second-order friends. 
    4: Input member name, to print the friends  
    5: Quit                       '''
    
def open_file(s):
    '''
    Repeatedly prompt for a file until it is valid
    's' is a string, open the file corresponding to the string
    '''
    while True:
       if s== 'names':
           prompt=input('\nInput a names file: \n')
       if s=='friends':
           prompt=input("Input a friends file: ")
       try:
           fp=open(prompt,'r')
           break
       except FileNotFoundError:
           print('Error: file not found.  Please try again.')
    return fp

def read_names(fp):
    '''
    Given a file pointer, read through the lines and make a list of each line
    '''
    name_list=[]
    for line in fp:
        #Strip newline character
        line=line.rstrip('\n')
        name_list.append(line)
    return name_list


def read_friends(fp,names_lst):
    '''
    Given a list of names, match these names with the indices of another list
    Read the csv file and make it a list
    Return the list of friends
    '''
    lst=[]
    for line in fp:
        #Strip characters, remove spaces, and split at commas
        line=line.rstrip(', \n')
        line=line.replace(" ","")
        line=line.split(",")
        for i in range(len(line)):
        #Turn the numbers into integers
            line[i]=int(line[i])
        lst.append(line)
    for i in lst:
        for x,ch in enumerate(i):
        #Each list will contain the names at the index from names_lst
            i[x]=names_lst[ch]
    return lst


def create_friends_dict(names_lst,friends_lst):
    '''
    Given the 2 lists, create a dictionary where the first list is the keys
    The second list contains the values
    The zip() function can do this in one line
    '''
    friends_dict={key:value for key,value in zip(names_lst,friends_lst)}
    return friends_dict
            
def find_common_friends(name1, name2, friends_dict):
    '''
    Given 2 names (keys), find the values that are in common with these keys
    Return the names in a set
    '''
    lst=[]
    for val in friends_dict[name1]:
        #Make sure names are not equal
        if val in friends_dict[name2] and val!=name1:
            lst.append(val)
    return set(lst)

def find_max_friends(names_lst, friends_lst):
    '''
    Find which list in the list of lists is the longest
    Return the names that have this length, and the length
    '''
    lst=[]
    names=[]
    #Make a list of the lengths
    for i in friends_lst:
        lst.append(len(i))
    x=max(lst)
    #If the element is the max, append the name to names_lst
    for i,ch in enumerate (lst):
        if ch==x:
            names.append(names_lst[i])
    names.sort()
    return names,x
   
def find_max_common_friends(friends_dict):
    '''
    With help from find_common_friends, find who has the most common friends
    Make all possible pairs of friends to call in the function
    Find which pairs have the most in common, and the max number
    Return the pair and the number
    '''
    key_list=[]
    lst1=[]
    lst2=[]
    return_list=[]
    sorted_list=[]
    for i in friends_dict.keys():
        key_list.append(i)
    for i in range(len(key_list)):
        for j in range(len(key_list)):
            #Cannot be equal
            if i==j:
                continue
            #If (I,J) is used, dont use (J,I)
            if j>i:
                continue
            lst1.append((key_list[i],key_list[j]))
    for i in lst1:
        y=find_common_friends(i[0],i[1],friends_dict)
        lst2.append(y)
    #Find max length in list of lists
    max_len=max(len(x)for x in lst2)
    
    for i,ch in enumerate(lst2):
        if len(ch)==max_len:
            return_list.append(lst1[i])
    for i in return_list:
    #Sort list to match output, and return the list and its length
        i=sorted(i,reverse=True)
        sorted_list.append(tuple(i))
    sorted_list.sort()
    return (sorted_list,max_len)
    
def find_second_friends(friends_dict):
    '''
    Find the secondary friends given the friends_dict
    Each value in a key is also another key, this helps to make this function
    Return the secondary dictionay
    '''
    dic2={}
    a=set()
    for k,v in friends_dict.items():
        for i in v:
            if k in friends_dict[i]:
            #Put all keys in a set
                a.update(friends_dict[i])
    
            if k not in dic2.keys():
            #Each value in second_dict cannot equal the key
            #Each value cannot be a friend of the key
            #Each value needs to be a friend of the friend
                dic2[k]={x for x in a if x not in friends_dict[k] and x!=k and x in friends_dict[i]}
            else:
                dic2[k].update({x for x in a if x not in friends_dict[k] and x!=k and x in friends_dict[i]})
    return dic2

def find_max_second_friends(seconds_dict):
    '''
    Given the seconds_dict, find the max secondary friends
    This is very similar to find_max_friends, but much simpler
    Return the person and the number of secondary friends
    '''
    lst=[]
    for val in seconds_dict.values():
        lst.append((len(val)))
    x=max(lst)
    #If the length of the values equals the max, that key is the person 
    person=[k for k,v in seconds_dict.items()if len(v)==x]
    return person,x
    
def main():
    '''
    Based on user choice, call functions as necessary 
    Print so it matches desired output
    '''
    print("\nFriend Network\n")
    fp = open_file("names")
    names_lst = read_names(fp)
    fp = open_file("friends")
    friends_lst = read_friends(fp,names_lst)
    friends_dict = create_friends_dict(names_lst,friends_lst)
    fp=fp.close()

    print(MENU)
    choice = input("\nChoose an option: ")
    while choice not in "12345":
        print("Error in choice. Try again.")
        choice = input("Choose an option: ")
        
    while choice != '5':

        if choice == "1":
            max_friends, max_val = find_max_friends(names_lst, friends_lst)
            print("\nThe maximum number of friends:", max_val)
            print("People with most friends:")
            for name in max_friends:
                print(name)
                
        elif choice == "2":
            max_names, max_val = find_max_common_friends(friends_dict)
            print("\nThe maximum number of commmon friends:", max_val)
            print("Pairs of non-friends with the most friends in common:")
            for name in max_names:
                name=sorted(name)
                print(tuple(name))
                
        elif choice == "3":
            seconds_dict = find_second_friends(friends_dict)
            max_seconds, max_val = find_max_second_friends(seconds_dict)
            print("\nThe maximum number of second-order friends:", max_val)
            print("People with the most second_order friends:")
            for name in max_seconds:
                print(name)
                
        elif choice == "4":
        #Prompt for a valid name, reprompt if not valid
        #If valid, print the values of that name
            name_prompt=input("\nEnter a name: ")
            while True:
                if name_prompt in friends_dict:
                    print('\nFriends of {}:'.format(name_prompt))
                    for i in friends_dict[name_prompt]:
                        print(i)
                    break
                else:
                    print("\nThe name",name_prompt,"is not in the list.")
                    name_prompt=input("\nEnter a name: ")



        else: 
            print("Shouldn't get here.")
            
        choice = input("\nChoose an option: ")
        while choice not in "12345":
            print("Error in choice. Try again.")
            choice = input("Choose an option: ")

if __name__ == "__main__":
    main()
