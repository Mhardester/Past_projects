    ###########################################################
    #  Cse 231 Project #7
    #  Define functions that return lists of lists
    #  Define functions that return lists of tuples
    #  Define functions that return sorted lists of integers
    #  Define functions to find maximum averages from these lists
    #  Bases on user input, call functions as necessary
    ###########################################################

from operator import itemgetter #used to sort a list
GENRES = ['Unknown','Action', 'Adventure', 'Animation',"Children's",
          'Comedy','Crime','Documentary', 'Drama', 'Fantasy', 'Film-noir',
          'Horror', 'Musical', 'Mystery', 'Romance', 'Sci-Fi', 'Thriller', 
          'War', 'Western']
OCCUPATIONS = ['administrator', 'artist', 'doctor', 'educator', 'engineer',
               'entertainment', 'executive', 'healthcare', 'homemaker', 'lawyer',
               'librarian', 'marketing', 'none', 'other', 'programmer', 'retired',
               'salesman', 'scientist', 'student', 'technician', 'writer']
'''
Three main data structures (lists)
L_users, indexed by userID, list of tuples (age,gender,occupation)
L_reviews, indexed by userID, list of tuples (movieID, rating)
L_movies, indexed by movieID, list of tuples (movieName, releaseDate, list of genres)
'''
MENU = '''
        Options:
        1. Highest rated movie for a specific year
        2. Highest rated movie for a specific Genre
        3. Highest rated movies by a specific Gender (M,F)
        4. Highest rated movies by a specific occupation
        5. Quit
        '''
def open_file(s):
   ''' 
   Repeatedly prompt for a filename until it is valid
   Return the file pointer
   '''
  
   while True:
       if s== 'users':
           prompt=input('\nInput users filename: \n')
       if s=='reviews':
           prompt=input("Input reviews filename: \n")
       if s== 'movies':
           prompt=input("Input movies filename: ")
       try:
           fp=open(prompt,'r',encoding="windows-1252")
           break
       except FileNotFoundError:
           print('Error: file not found.  Please try again.')
   return fp
 
def read_reviews(N,fp):
   ''' 
   Read a file and create a list from the file
   Each element in the list is a tuple containing a movie and its review
   Sort the list based on the first element in each tuple
   Return the list of tuples
   '''
   new_list=[]
   for i in range(N+1):
       new_list.append([])
   for line in fp:
       #Each element in the line is spaced out by a tab, remove the tabs
           line=line.split("\t")
           line.pop()
           index=int(line[0])
           line[1]=int(line[1])
           line[2]=int(line[2])
           if index<=N+1:
               #The new list is indexed by ID
               new_list[index].append(line[1:])
   for i in new_list:
       #Sort each list by the first element
       i.sort(key=itemgetter(0))
   for i in new_list:
       for x,ch in enumerate(i):
           #Each element needs to be a tuple
           i[x]=tuple(ch)
   return new_list
 
 
 
def read_users(fp):
   '''
   Read each line in a file, and make a list of tuples for each line
   Return a list of each element 
   '''
   new_list=[]
   new_list.append([])
   for line in fp:
       #Each element is separated by "|"
       line=line.split("|")
       line.pop()
       line.pop(0)
       #Make each number an integer
       line[0]=int(line[0])
       #Make each line a tuple
       line=tuple(line)
       new_list.append(line)
   return new_list
 
def read_movies(fp):
   ''' 
   This function returns a list, each element is a list of tuples
   The last element in each tuple is a list of the genres of the movie
   Genres are 1's and 0's, but are indexed the same as the GENRES list
   '''
   movie_list=[]
   _list=[]
   li=[]
   for line in fp:
       line=line.split("|")
       line.pop(3)
       line.pop(3)
       m1=line[1:3]
       #Genres need to be in a list
       m2=[line[3:]]
       movie_list.append(m1+m2)
   for i in movie_list:
       for x,ch in enumerate(i[2]):
           #Change 1s and the newline character to each corresponding genre
           if i[2][x]=='1' or i[2][x]=='1\n':
               i[2][x]=GENRES[x]
       _list.append(i)
   for i in _list:
       movies=i[0:2]
       for g in i[2]:
           #List comprehension helps to remove all zeroes
           g=[[c for c in i[2] if c!='0' and c!='0\n']]
       li.append(movies+g)
   #List comprehension also helps make each element into a tuple
   li=[tuple(i)for i in li]
   li.insert(0,[])
 
   return li
      
def year_movies(year,L_movies):
   '''
   Given a year input, make a list of movies from that year
   Each element in the list is the index of the movie
   '''
   int_list=[]
   #Use enumerate, and skip the first index of the list
   for i,tup in enumerate(L_movies[1:],0):
       if "-" in tup[1]:
           l_year=tup[1][-4:]
       l_year=int(l_year)
       if year== l_year:
        #To make up for the skipped index, use i+1
           int_list.append(i+1)
   return int_list
 
def genre_movies(genre,L_movies):
   ''' 
   Very similar to the year function, but this list is for genres
   '''
   genre_list=[]
   for i,tup in enumerate(L_movies[1:],0):
       if genre in tup[2]:
           genre_list.append(i+1)
   return genre_list
 
def gen_users (gender, L_users, L_reviews):
   ''' 
   Given an input gender, make a list of movies reviewed by that gender
   Return the list
   '''
   g_list=[]
   #List comprehension is used to make a list of valid genres by index
   result=[i+1 for i, tup in enumerate(L_users[1:]) if tup[1] == gender]
   #Use enumerate to append the tuples to the list if index matches
   for i, tup in enumerate(L_reviews):
       if i in result:
           g_list.append(tup)
   return g_list  
  
  
      
 
        
def occ_users (occupation, L_users, L_reviews):
   '''
   This function is the exact same as the previous function
   THe only difference is sorting the list by occupation instead of genre 
   '''
   o_list=[]
   result=[i+1 for i, tup in enumerate(L_users[1:]) if tup[2] == occupation]
   for i, tup in enumerate(L_reviews):
       if i in result:
           o_list.append(tup)
   return o_list  
 
def highest_rated_by_movie(L_in,L_reviews,N_movies):
    ''' 
    Given the list returned by the reviews function, and a list of integers,
    Find the average rating of each movie and find the max average
    Make a new list where each element is the sum of a movie's score 
    The 2nd element is the number of people who reviewed that movie
    Return max average and movies with that average
    '''
    #Initialize average list
    a_list=[[0,0]]
    avg_list=[]
    int_list=[]
    #Each element will start as [0,0]
    for i in range(N_movies):
        a_list.append([0,0])
    for lst in L_reviews:
        if len(lst)==0:
            continue
        for tup in lst:
            movie_ID=tup[0]
            movie_review=tup[1]
            if movie_ID in L_in:
            #Change each element to the sums and counts of each movie
                a_list[movie_ID][0]+=movie_review
                a_list[movie_ID][1]+=1
    for i in a_list:
        try:
            #Find the average of the elements by dividing the sum by count
            i=i[0]/i[1]
            avg_list.append(round(i,2))
        except ZeroDivisionError:
            avg_list.append(0.0)
    x=max(avg_list)
    for i,ch in enumerate(avg_list):
        #Each element in int_list is the index of movies with the max average
        if ch==x and i in L_in:
            int_list.append(i)
    return int_list,x
           
def highest_rated_by_reviewer(L_in,N_movies):
    ''' 
    This function has a similar process to the previous one
    This function finds the max average by the reviewers, instead of movie
    Return the list of movies with the max average, and the average
    '''
    a_list=[[0,0]]
    int_list=[]
    avg_list=[]
    for i in range (N_movies):
        a_list.append([0,0])
    for i in L_in:
        for tup in i:
            #Each index in the a_list is once again the sums and counts
            m_ID=tup[0]
            m_review=tup[1]
            a_list[m_ID][0]+=m_review
            a_list[m_ID][1]+=1
    for i in a_list:
        try:
            #Calculate the average with the same method as before
            i=i[0]/i[1]
            avg_list.append(round(i,2))
        except ZeroDivisionError:
            avg_list.append(0.0)
    x=max(avg_list)
    for i,ch in enumerate(avg_list):
        #Append the movies with the max average
        if ch==x:
            int_list.append(i)
    return int_list,x
    


    
def main():
   '''
   Use open file to access all files
   Create the master lists using the read functions
   Based on an input, calculate averages of movies based on select criteria
   Error check every input 
   Inputting '5' ends the loop
   '''
   #Create lists by opening each file
   a=open_file('users')
   b=open_file('reviews')
   c=open_file('movies')
   movie_list=read_movies(c)
   users_list=read_users(a)
   reviews_list=read_reviews(len(users_list),b)
   print(MENU)
   print()
   #Close files once lists are created
   a=a.close()
   b=b.close()
   c=c.close()
   prompt=input('Select an option (1-5): ')
   while prompt !='5':
        while True:
            #Error check
            if int(prompt)>5 or int(prompt)<1:
                print("\nError: not a valid option.")
                prompt=input('\nSelect an option (1-5): ')
            else:
                break
        if prompt =='1':
            year = input("\nInput a year: ")
            while True:
                try:
                    #Error check
                    year= int(year)
                    if year >1998 or year <1930:
                        print("\nError in year.")
                        year = input("\nInput a year: ")
                    else:
                        break
                except ValueError:
                    year=input("Input a year: ")
            #Find highest average based on a year
            year_id=year_movies(year,movie_list)
            hry_movie_list,average= highest_rated_by_movie(year_id,reviews_list,len(movie_list))
            print("\nAvg max rating for the year is:",average)
            #If a movie has the max average, print the movie name
            for i,ch in enumerate(movie_list):
                if i in hry_movie_list:
                    print(ch[0])
            prompt=input('\nSelect an option (1-5): ')
        
        if prompt =='2':
            print("\nValid Genres are: ",GENRES)
            genre=input("Input a genre: ")
            genre=genre.capitalize()
            while True:
                #Error check
                if genre not in GENRES:
                    print("\nError in genre.")
                    genre=input("Input a genre: ")
                    genre=genre.capitalize()
                else:
                    break
                    #Find average based on genre
            g_list=genre_movies(genre,movie_list)
            hrg_list,average2=highest_rated_by_movie(g_list,reviews_list,len(movie_list))
            print("\nAvg max rating for the Genre is:",average2)
            #If a movie has the max average, print the movie name
            for i,ch in enumerate (movie_list):
                if i in hrg_list:
                    print(ch[0])
            prompt=input('\nSelect an option (1-5): ')
        
        if prompt == '3':
            options=['M','F']
            gender=input("\nInput a gender (M,F): ")
            gender=gender.upper()
            while True:
                if gender not in options:
                    #Error check
                    print("\nError in gender.")
                    gender=input("\nInput a gender (M,F): ")
                    gender=gender.upper()
                else:
                    break
                    #Find average based on gender
            gen_list=gen_users(gender,users_list,reviews_list)
            hrgen_list,average3=highest_rated_by_reviewer(gen_list,len(movie_list))
            print("\nAvg max rating for the Gender is:",average3)
            #If a movie has the max average, print the movie name
            for i,ch in enumerate (movie_list):
                if i in hrgen_list:
                    print(ch[0])
            prompt=input('\nSelect an option (1-5): ')
        
        if prompt == '4':
            print("\nValid Occupatipns are: ",OCCUPATIONS)
            occupation=input("Input an occupation: ")
            occupation=occupation.lower()
            while True:
                if occupation not in OCCUPATIONS:
                    #Error check
                    print("\nError in occupation.")
                    occupation=input("Input an occupation: ")
                    occupation=occupation.lower()
                else:
                    break
                    #Find average of movies based on occupation
            occ_list=occ_users(occupation,users_list,reviews_list)
            hro_list,average4=highest_rated_by_reviewer(occ_list,len(movie_list))
            print("\nAvg max rating for the occupation is:",average4)
            #If a movie has the max average, print the movie name
            for i,ch in enumerate (movie_list):
                if i in hro_list:
                    print(ch[0])
            prompt=input('\nSelect an option (1-5): ')

if __name__ == "__main__":
   main()
                                         