
    ###########################################################
    #  Cse 231 Project #2
    #  Ask player if they want to continue
    #  Ask player to input their code
    #  Ask player for odometer readings and how many days car was rented
    #  Calculate the amount due for each player based on their input
    #  Print Results
    ###########################################################  

import math #needed for week calculations

BANNER = "\nWelcome to Horizons car rentals. \
\n\nAt the prompts, please enter the following: \
\n\tCustomer's classification code (a character: BD, D, W) \
\n\tNumber of days the vehicle was rented (int)\
\n\tOdometer reading at the start of the rental period (int)\
\n\tOdometer reading at the end of the rental period (int)" 
print(BANNER)

PROMPT = input("\nWould you like to continue (A/B)? \n")
while PROMPT=="A": #each indiivdual input code needs their own "if" statement
    
    code=input("\nCustomer code (BD, D, W): \n")
    
    while not (code=="W" or code=="BD" or code=="D"):
        print("\n\t*** Invalid customer code. Try again. ***")
        code=input("\nCustomer code (BD, D, W): \n")

    if code =="BD":  
        BD_days=int(input("\nNumber of days: \n"))
        BD_start=int(input("Odometer reading at the start: \n"))
        BD_end=int(input("Odometer reading at the end:   \n"))
        if BD_start>BD_end: #add one million to "negative" mileage
            BD_miles_driven=float((BD_end-BD_start+1000000)/(10))
        else:
            BD_miles_driven=float((BD_end-BD_start)/(10))
        BD_amount_due=(BD_days*40)+(BD_miles_driven*0.25)
        print("\nCustomer summary:")
        print("\tclassification code:",code)
        print("\trental period (days):",BD_days)
        print("\todometer reading at start:",BD_start)
        print("\todometer reading at end:  ",BD_end)
        print("\tnumber of miles driven: ",BD_miles_driven)
        print("\tamount due: $",round(BD_amount_due,2))
        #print summary at end of each "if" statement

    elif code== "D":
        D_days=int(input("\nNumber of days: \n"))
        D_start=int(input("Odometer reading at the start: \n"))
        D_end=int(input("Odometer reading at the end:   \n"))
        D_miles_driven=float((D_end-D_start)/(10))
        D_Average=D_miles_driven/D_days
        if D_Average > 100:
            D_amount_due= float((D_days*60)+(D_Average-100)* D_days*0.25)
        elif D_Average <= 100:
            D_amount_due= float((D_days*60))
        print("\nCustomer summary:")
        print("\tclassification code:",code)
        print("\trental period (days):",D_days)
        print("\todometer reading at start:",D_start)
        print("\todometer reading at end:  ",D_end)
        print("\tnumber of miles driven: ",D_miles_driven)
        print("\tamount due: $",round(D_amount_due,2))
         
    elif code=="W":
        W_days=int(input("\nNumber of days: \n"))
        W_start=int(input("Odometer reading at the start: \n"))
        W_end=int(input("Odometer reading at the end:   \n"))
        Week=W_days/7
        Week=math.ceil(Week)
        W_miles_driven=float((W_end-W_start)/(10))
        W_Average=W_miles_driven/Week
        if W_Average > 900 and W_Average<=1500:
            W_amount_due= float((Week*190) + (Week*100))
        elif W_Average <= 900:
            W_amount_due= float((Week*190))
        elif W_Average >1500:
            W_amount_due= float((Week*200)+(Week*190)+(W_Average-1500)*Week*0.25)
        print("\nCustomer summary:")
        print("\tclassification code:",code)
        print("\trental period (days):",W_days)
        print("\todometer reading at start:",W_start)
        print("\todometer reading at end:  ",W_end)
        print("\tnumber of miles driven: ",W_miles_driven)
        print("\tamount due: $",round(W_amount_due,2))
    #The loop needs to end when player hits "B", otherwise it repeats    
    PROMPT = input("\nWould you like to continue (A/B)? \n")
print("Thank you for your loyalty.")